# OpenToday
Android application for the organization of life

# Coming soon...
Application is development.

# Other Development Docs
"/docs" folder
