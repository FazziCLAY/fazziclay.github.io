package ru.fazziclay.opentoday.util;

public class Tests {
    private void owo_owo_owo_wo() {
    }
}
