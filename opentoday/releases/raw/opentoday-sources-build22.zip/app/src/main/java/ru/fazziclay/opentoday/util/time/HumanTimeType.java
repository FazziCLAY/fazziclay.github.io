package ru.fazziclay.opentoday.util.time;

/**
 * Специально для {@link TimeUtil#getHumanValue(long, HumanTimeType)}
 * **/
public enum HumanTimeType {
    SECONDS_OF_MINUTE,
    MINUTE_OF_HOUR,
    HOUR
}
