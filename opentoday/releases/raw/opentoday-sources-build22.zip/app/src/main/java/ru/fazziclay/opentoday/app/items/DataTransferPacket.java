package ru.fazziclay.opentoday.app.items;

import java.util.ArrayList;
import java.util.List;

import ru.fazziclay.opentoday.app.items.item.Item;

public class DataTransferPacket {
    public List<Item> items = new ArrayList<>();
}
