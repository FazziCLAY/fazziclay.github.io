# OpenToday
Android application for the organization of life

# Coming soon...
soon... :) (test discord webhook111)

# Other Development Docs
"/docs" folder
