package ru.fazziclay.opentoday.app.items;

import org.junit.Test;

public class TestItems {

}
