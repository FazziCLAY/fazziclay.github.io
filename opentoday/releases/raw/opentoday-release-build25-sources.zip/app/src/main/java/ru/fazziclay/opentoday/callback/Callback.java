package ru.fazziclay.opentoday.callback;

/**
 * Все Callback должны наследовать этот интерфейс
 * @see CallbackStorage
 * **/
public interface Callback {
}
