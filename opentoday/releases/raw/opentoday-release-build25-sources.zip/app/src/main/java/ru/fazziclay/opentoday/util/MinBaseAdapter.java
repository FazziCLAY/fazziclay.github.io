package ru.fazziclay.opentoday.util;

import android.widget.BaseAdapter;

public abstract class MinBaseAdapter extends BaseAdapter {
    @Override
    public Object getItem(int position) {
        return null;
    }
    @Override
    public long getItemId(int position) {
        return 0;
    }
}
