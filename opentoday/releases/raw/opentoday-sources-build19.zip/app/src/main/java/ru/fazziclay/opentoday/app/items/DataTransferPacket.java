package ru.fazziclay.opentoday.app.items;

import java.util.ArrayList;
import java.util.List;

public class DataTransferPacket {
    protected List<Item> items = new ArrayList<>();
}
