package ru.fazziclay.opentoday.app;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;

import ru.fazziclay.opentoday.R;
import ru.fazziclay.opentoday.app.items.ItemManager;

public class MainService extends Service {
    private Handler handler;
    private Runnable runnable;
    private long latestTick;

    private ItemManager itemManager;

    @Override
    public void onCreate() {
        super.onCreate();

        startForeground(App.NOTIFICATION_FOREGROUND_ID, new NotificationCompat.Builder(this, App.NOTIFICATION_FOREGROUND_CHANNEL)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setSilent(true)
                .setSound(null)
                .setShowWhen(false)
                .setContentTitle(getString(R.string.notification_foreground_title))
                .setContentText(getString(R.string.notification_foreground_text))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .build());

        App app = App.get(this);
        itemManager = app.getItemManager();
        handler = new Handler(getMainLooper());
        runnable = () -> {
            itemManager.tick();
            handler.removeCallbacks(runnable);
            handler.postDelayed(runnable, 1000);
        };
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        handler.post(runnable);
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}